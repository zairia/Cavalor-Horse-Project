(function($){
	$(document).ready(function() {	

		// Scroll to Top
		jQuery('.scrolltotop').click(function(){
			jQuery('html').animate({'scrollTop' : '0px'}, 400);
			return false;
		});
		
		jQuery(window).scroll(function(){
			var upto = jQuery(window).scrollTop();
			if(upto > 500) {
				jQuery('.scrolltotop').fadeIn();
			} else {
				jQuery('.scrolltotop').fadeOut();
			}
		});

		$('.main-carousel').flickity({				
			  // options
			  cellAlign: 'center',
			  contain: true,
			  groupCells: true,
			  freeScroll: true,
			  wrapAround: true,
			  groupCells: 1,
			  // groupCells: '100%',
			 autoPlay: false,
			 // autoPlay: 1500,
			 pauseAutoPlayOnHover: false,
			 initialIndex: 1,
			 wrapAround: true,
			 prevNextButtons: true,
			 pageDots: true

			});
		

				
		
		
		
		
		
		
		
		
	});
})(jQuery);